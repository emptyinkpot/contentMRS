
# AuthorProfileResponse


## Properties

Name | Type
------------ | -------------
`profile` | { [key: string]: any; }
`interestClusters` | Array&lt;{ [key: string]: any; }&gt;
`authorTechniques` | [Array&lt;CreativeAuthorTechnique&gt;](CreativeAuthorTechnique.md)
`counts` | { [key: string]: number; }
`requestId` | string

## Example

```typescript
import type { AuthorProfileResponse } from '@emptyinkpot/database-gateway-generated-client'

// TODO: Update the object below with actual values
const example = {
  "profile": null,
  "interestClusters": null,
  "authorTechniques": null,
  "counts": null,
  "requestId": null,
} satisfies AuthorProfileResponse

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as AuthorProfileResponse
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)

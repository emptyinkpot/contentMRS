
# ResolvedCreativeContextPublicationState


## Properties

Name | Type
------------ | -------------
`targets` | [Array&lt;ResolvedCreativeContextPublicationStateTargetsInner&gt;](ResolvedCreativeContextPublicationStateTargetsInner.md)
`constraints` | Array&lt;string&gt;

## Example

```typescript
import type { ResolvedCreativeContextPublicationState } from '@emptyinkpot/database-gateway-generated-client'

// TODO: Update the object below with actual values
const example = {
  "targets": null,
  "constraints": null,
} satisfies ResolvedCreativeContextPublicationState

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as ResolvedCreativeContextPublicationState
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)

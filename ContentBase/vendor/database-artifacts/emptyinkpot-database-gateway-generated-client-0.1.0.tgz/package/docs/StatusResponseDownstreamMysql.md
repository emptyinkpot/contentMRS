
# StatusResponseDownstreamMysql


## Properties

Name | Type
------------ | -------------
`database` | string
`user` | string

## Example

```typescript
import type { StatusResponseDownstreamMysql } from '@emptyinkpot/database-gateway-generated-client'

// TODO: Update the object below with actual values
const example = {
  "database": null,
  "user": null,
} satisfies StatusResponseDownstreamMysql

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as StatusResponseDownstreamMysql
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)


# OpenListTargetFsGetResponse


## Properties

Name | Type
------------ | -------------
`item` | [OpenListFileObject](OpenListFileObject.md)
`requestId` | string
`target` | [OpenListTarget](OpenListTarget.md)

## Example

```typescript
import type { OpenListTargetFsGetResponse } from '@emptyinkpot/database-gateway-generated-client'

// TODO: Update the object below with actual values
const example = {
  "item": null,
  "requestId": null,
  "target": null,
} satisfies OpenListTargetFsGetResponse

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as OpenListTargetFsGetResponse
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)


# RecordArticleAcceptanceReportResult


## Properties

Name | Type
------------ | -------------
`workId` | number
`chapterId` | number
`chapterNumber` | number
`partId` | string
`blockId` | string
`reportId` | string
`passed` | boolean
`contractId` | string
`blockCount` | number
`warningCount` | number

## Example

```typescript
import type { RecordArticleAcceptanceReportResult } from '@emptyinkpot/database-gateway-generated-client'

// TODO: Update the object below with actual values
const example = {
  "workId": null,
  "chapterId": null,
  "chapterNumber": null,
  "partId": null,
  "blockId": null,
  "reportId": null,
  "passed": null,
  "contractId": null,
  "blockCount": null,
  "warningCount": null,
} satisfies RecordArticleAcceptanceReportResult

console.log(example)

// Convert the instance to a JSON string
const exampleJSON: string = JSON.stringify(example)
console.log(exampleJSON)

// Parse the JSON string back to an object
const exampleParsed = JSON.parse(exampleJSON) as RecordArticleAcceptanceReportResult
console.log(exampleParsed)
```

[[Back to top]](#) [[Back to API list]](../README.md#api-endpoints) [[Back to Model list]](../README.md#models) [[Back to README]](../README.md)

import { DefaultApi } from "./apis/DefaultApi";
import { Configuration, type Middleware } from "./runtime";
import type {
  GatewayMutationResponse,
  GatewayWriteEnvelope,
  HealthResponse,
  StatusResponse,
} from "./models";

export interface DatabaseClientOptions {
  baseUrl?: string;
  apiKey?: string;
  actor?: string;
  fetchApi?: typeof fetch;
}

export interface WriteOptions {
  idempotencyKey?: string;
  requestId?: string;
  actor?: string;
}

export interface VocabularyInput {
  content: string;
  type?: string;
  category?: string;
  note?: string | null;
  tags?: string[];
}

export interface NoteInput {
  title: string;
  content?: string | null;
  category?: string;
  tags?: string[];
}

export interface ExperienceInput {
  title?: string;
  content?: string;
  type?: string;
  source?: string;
  tags?: string[];
  metadata?: Record<string, unknown>;
}

export interface WorkInput {
  title: string;
  description?: string | null;
  targetChapters?: number;
  currentChapters?: number;
  status?: string;
  platform?: string;
  metadata?: Record<string, unknown>;
}

export interface SemanticReferenceMaterialInput {
  sourceId: string;
  sourceTitle: string;
  sourceAuthor?: string | null;
  sourceLocator?: string | null;
  excerpt: string;
  summary?: string | null;
  materialKind?: string;
  status?: string;
  tags?: Array<Record<string, unknown>>;
}

export interface StyleRevisionPairInput {
  pairId?: string;
  sourceId?: string;
  sourceTitle?: string;
  sourceLocator?: string;
  topic?: string;
  target?: string;
  issueType: string;
  ruleId: string;
  severity?: "block" | "warn" | "info";
  originalText: string;
  revisedText?: string;
  reviewerEvidence: {
    badReason: string;
    rewriteActions: string[];
    forbiddenMoves: string[];
    targetShape: string;
  };
  status?: "candidate" | "active" | "retired";
  metadata?: Record<string, unknown>;
  tags?: Array<Record<string, unknown>>;
}

export interface PublicationAccountQuery {
  accountId?: string;
  limit?: number;
}

export interface PublicationPublishContextQuery {
  accountId?: string;
  bookId?: string;
  remoteWorkId?: string;
  localWorkId?: string | number;
  limit?: number;
}

export interface PublicationPublishChapterQuery {
  accountId?: string;
  bookId?: string;
  remoteWorkId?: string;
  localWorkId?: string | number;
  chapterId?: string | number;
  chapterNumber?: number;
  requestId?: string;
}

export interface PublicationRemoteChaptersQuery {
  accountId?: string;
  bookId?: string;
  remoteWorkId?: string;
  limit?: number;
}

export interface SyncFanqieWorksInput {
  works: Array<Record<string, unknown>>;
}

export interface RecordFanqieAccountSessionInput {
  accountId: string;
  cookiesPayload: Record<string, unknown> | string;
  cookieChecksum: string;
  cookieCount: number;
  expiresSummary?: Record<string, unknown>;
}

export interface SyncFanqieRemoteChaptersInput {
  accountId: string;
  bookId: string;
  chapterCount?: number;
  chapters: Array<Record<string, unknown>>;
}

export interface RegisterPublicationTargetInput {
  targetId?: string;
  accountId?: string;
  accountIdentity?: string;
  bookId?: string;
  remoteWorkId?: string;
  localWorkId: string | number;
  title?: string;
  author?: string | null;
  status?: string;
  metadata?: Record<string, unknown>;
}

export interface RecordPublicationResultInput {
  targetId?: string;
  platform?: "fanqie";
  accountId: string;
  bookId: string;
  localWorkId: string | number;
  chapterId?: string | number;
  chapterNumber: number;
  contentPartId?: string;
  action: "publish_chapter" | "edit_chapter";
  remotePartId?: string;
  observedStatus: "submitted" | "published" | "edited" | "failed";
  publishedAt?: string;
  result?: Record<string, unknown>;
}

export interface DatabaseClient {
  raw: DefaultApi;
  health(): Promise<HealthResponse>;
  status(): Promise<StatusResponse>;
  inventory: {
    tables(): ReturnType<DefaultApi["getTableInventory"]>;
  };
  search: {
    content(query: string, options?: { limit?: number }): ReturnType<DefaultApi["searchContent"]>;
    vocabulary(query: string, options?: { limit?: number }): ReturnType<DefaultApi["searchVocabulary"]>;
  };
  vocabulary: {
    search(query: string, options?: { limit?: number }): ReturnType<DefaultApi["searchVocabulary"]>;
    upsert(input: VocabularyInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
  };
  works: {
    list(options?: Parameters<DefaultApi["listWorks"]>[0]): ReturnType<DefaultApi["listWorks"]>;
    create(input: WorkInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    upsert(input: WorkInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    chapters(workId: string | number, options?: { limit?: number }): ReturnType<DefaultApi["listWorkChapters"]>;
    characters(workId: string | number, options?: { limit?: number }): ReturnType<DefaultApi["listWorkCharacters"]>;
  };
  publication: {
    targets(options?: Parameters<DefaultApi["listCanonicalPublicationTargets"]>[0]): ReturnType<DefaultApi["listCanonicalPublicationTargets"]>;
    accounts(options?: PublicationAccountQuery): Promise<Record<string, unknown>>;
    publishContext(options?: PublicationPublishContextQuery): Promise<Record<string, unknown>>;
    publishChapter(options: PublicationPublishChapterQuery): Promise<Record<string, unknown>>;
    remoteChapters(options?: PublicationRemoteChaptersQuery): Promise<Record<string, unknown>>;
    recordFanqieAccountSession(input: RecordFanqieAccountSessionInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    registerTarget(input: RegisterPublicationTargetInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    recordResult(input: RecordPublicationResultInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    syncFanqieWorks(input: SyncFanqieWorksInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
    syncFanqieRemoteChapters(input: SyncFanqieRemoteChaptersInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
  };
  fanqie: {
    works(options?: Parameters<DefaultApi["listFanqieWorks"]>[0]): ReturnType<DefaultApi["listFanqieWorks"]>;
  };
  notes: {
    list(options?: Parameters<DefaultApi["listNotes"]>[0]): ReturnType<DefaultApi["listNotes"]>;
    get(id: string | number): ReturnType<DefaultApi["getNote"]>;
    record(input: NoteInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
  };
  semantic: {
    units(options?: Parameters<DefaultApi["listSemanticUnits"]>[0]): ReturnType<DefaultApi["listSemanticUnits"]>;
    tags(options?: Parameters<DefaultApi["listSemanticTags"]>[0]): ReturnType<DefaultApi["listSemanticTags"]>;
    relations(options?: Parameters<DefaultApi["listSemanticRelations"]>[0]): ReturnType<DefaultApi["listSemanticRelations"]>;
    recordReferenceMaterial(
      input: SemanticReferenceMaterialInput,
      options?: WriteOptions
    ): ReturnType<DefaultApi["recordSemanticReferenceMaterial"]>;
    recordStyleRevisionPair(
      input: StyleRevisionPairInput,
      options?: WriteOptions
    ): ReturnType<DefaultApi["recordStyleRevisionPair"]>;
  };
  creative: {
    styleContract(options?: Parameters<DefaultApi["getCreativeStyleContract"]>[0]): ReturnType<DefaultApi["getCreativeStyleContract"]>;
    context(options: Parameters<DefaultApi["resolveCreativeContext"]>[0]): ReturnType<DefaultApi["resolveCreativeContext"]>;
    authorProfile(options?: Parameters<DefaultApi["getAuthorProfile"]>[0]): ReturnType<DefaultApi["getAuthorProfile"]>;
    storyMemory(options: Parameters<DefaultApi["getStoryMemory"]>[0]): ReturnType<DefaultApi["getStoryMemory"]>;
    storyMemoryContext(options: Parameters<DefaultApi["getStoryMemoryContext"]>[0]): ReturnType<DefaultApi["getStoryMemoryContext"]>;
  };
  memory: {
    experiences(options?: Parameters<DefaultApi["listExperienceRecords"]>[0]): ReturnType<DefaultApi["listExperienceRecords"]>;
    recordExperience(input: ExperienceInput, options?: WriteOptions): Promise<GatewayMutationResponse>;
  };
}

const DEFAULT_BASE_URL = "https://database.tengokukk.com";
const DEFAULT_ACTOR = "database-client";

export function createDatabaseClient(options: DatabaseClientOptions = {}): DatabaseClient {
  const actor = options.actor || DEFAULT_ACTOR;
  const apiKey = options.apiKey;
  const middleware: Middleware[] = apiKey
    ? [
        {
          pre: async ({ url, init }) => ({
            url,
            init: {
              ...init,
              headers: {
                ...(init.headers || {}),
                "X-DataBase-Api-Key": apiKey,
              },
            },
          }),
        },
      ]
    : [];

  const raw = new DefaultApi(
    new Configuration({
      basePath: trimTrailingSlash(options.baseUrl || DEFAULT_BASE_URL),
      fetchApi: options.fetchApi,
      middleware,
    })
  );

  const envelope = (payload: object, writeOptions?: WriteOptions): GatewayWriteEnvelope => ({
    requestId: writeOptions?.requestId || makeRequestId(),
    actor: writeOptions?.actor || actor,
    payload: payload as { [key: string]: unknown },
  });

  const writeKey = (operation: string, payload: unknown, writeOptions?: WriteOptions): string =>
    writeOptions?.idempotencyKey || `database-client:${operation}:${stableHash(payload)}`;

  const rawGet = async <T>(path: string): Promise<T> => {
    const response = await fetchWithAuth(trimTrailingSlash(options.baseUrl || DEFAULT_BASE_URL) + path, {
      method: "GET",
      apiKey,
      fetchApi: options.fetchApi,
    });
    return response as T;
  };

  const rawPost = async <T>(path: string, payload: object, operation: string, writeOptions?: WriteOptions): Promise<T> => {
    const response = await fetchWithAuth(trimTrailingSlash(options.baseUrl || DEFAULT_BASE_URL) + path, {
      method: "POST",
      apiKey,
      fetchApi: options.fetchApi,
      idempotencyKey: writeKey(operation, payload, writeOptions),
      body: envelope(payload, writeOptions),
    });
    return response as T;
  };

  return {
    raw,
    health: () => raw.getHealth(),
    status: () => raw.getStatus(),
    inventory: {
      tables: () => raw.getTableInventory(),
    },
    search: {
      content: (query, searchOptions = {}) => raw.searchContent({ q: query, limit: searchOptions.limit }),
      vocabulary: (query, searchOptions = {}) => raw.searchVocabulary({ q: query, limit: searchOptions.limit }),
    },
    vocabulary: {
      search: (query, searchOptions = {}) => raw.searchVocabulary({ q: query, limit: searchOptions.limit }),
      upsert: (input, writeOptions) =>
        raw.upsertVocabularyItem({
          xDataBaseIdempotencyKey: writeKey("vocabulary.upsert", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
    },
    works: {
      list: (listOptions = {}) => raw.listWorks(listOptions),
      create: (input, writeOptions) =>
        raw.createWork({
          xDataBaseIdempotencyKey: writeKey("works.create", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
      upsert: (input, writeOptions) =>
        raw.upsertWork({
          xDataBaseIdempotencyKey: writeKey("works.upsert", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
      chapters: (workId, listOptions = {}) => raw.listWorkChapters({ id: String(workId), limit: listOptions.limit }),
      characters: (workId, listOptions = {}) => raw.listWorkCharacters({ id: String(workId), limit: listOptions.limit }),
    },
    publication: {
      targets: (listOptions = {}) => raw.listCanonicalPublicationTargets(listOptions),
      accounts: (listOptions = {}) =>
        rawGet(`/content/publication/accounts${toQuery({
          account_id: listOptions.accountId,
          limit: listOptions.limit,
        })}`),
      publishContext: (listOptions = {}) =>
        rawGet(`/content/publication/publish-context${toQuery({
          account_id: listOptions.accountId,
          book_id: listOptions.bookId,
          remote_work_id: listOptions.remoteWorkId,
          local_work_id: listOptions.localWorkId,
          limit: listOptions.limit,
        })}`),
      publishChapter: (listOptions) =>
        rawGet(`/content/publication/publish-chapter${toQuery({
          account_id: listOptions.accountId,
          book_id: listOptions.bookId,
          remote_work_id: listOptions.remoteWorkId,
          local_work_id: listOptions.localWorkId,
          chapter_id: listOptions.chapterId,
          chapter_number: listOptions.chapterNumber,
          request_id: listOptions.requestId,
        })}`),
      remoteChapters: (listOptions = {}) =>
        rawGet(`/content/publication/remote-chapters${toQuery({
          account_id: listOptions.accountId,
          book_id: listOptions.bookId,
          remote_work_id: listOptions.remoteWorkId,
          limit: listOptions.limit,
        })}`),
      recordFanqieAccountSession: (input, writeOptions) =>
        rawPost("/writes/publication/record-fanqie-account-session", input, "publication.recordFanqieAccountSession", writeOptions),
      registerTarget: (input, writeOptions) =>
        rawPost("/writes/publication/register-target", input, "publication.registerTarget", writeOptions),
      recordResult: (input, writeOptions) =>
        rawPost("/writes/publication/record-result", input, "publication.recordResult", writeOptions),
      syncFanqieWorks: (input, writeOptions) =>
        rawPost("/writes/publication/sync-fanqie-works", input, "publication.syncFanqieWorks", writeOptions),
      syncFanqieRemoteChapters: (input, writeOptions) =>
        rawPost("/writes/publication/sync-fanqie-remote-chapters", input, "publication.syncFanqieRemoteChapters", writeOptions),
    },
    fanqie: {
      works: (listOptions = {}) => raw.listFanqieWorks(listOptions),
    },
    notes: {
      list: (listOptions = {}) => raw.listNotes(listOptions),
      get: (id) => raw.getNote({ id: String(id) }),
      record: (input, writeOptions) =>
        raw.recordNote({
          xDataBaseIdempotencyKey: writeKey("notes.record", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
    },
    semantic: {
      units: (listOptions = {}) => raw.listSemanticUnits(listOptions),
      tags: (listOptions = {}) => raw.listSemanticTags(listOptions),
      relations: (listOptions = {}) => raw.listSemanticRelations(listOptions),
      recordReferenceMaterial: (input, writeOptions) =>
        raw.recordSemanticReferenceMaterial({
          xDataBaseIdempotencyKey: writeKey("semantic.referenceMaterial.record", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
      recordStyleRevisionPair: (input, writeOptions) =>
        raw.recordStyleRevisionPair({
          xDataBaseIdempotencyKey: writeKey("semantic.styleRevisionPair.record", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
    },
    creative: {
      styleContract: (styleOptions = {}) => raw.getCreativeStyleContract(styleOptions),
      context: (contextOptions) => raw.resolveCreativeContext(contextOptions),
      authorProfile: (profileOptions = {}) => raw.getAuthorProfile(profileOptions),
      storyMemory: (storyOptions) => raw.getStoryMemory(storyOptions),
      storyMemoryContext: (storyOptions) => raw.getStoryMemoryContext(storyOptions),
    },
    memory: {
      experiences: (listOptions = {}) => raw.listExperienceRecords(listOptions),
      recordExperience: (input, writeOptions) =>
        raw.recordExperience({
          xDataBaseIdempotencyKey: writeKey("memory.experience.record", input, writeOptions),
          gatewayWriteEnvelope: envelope(input, writeOptions),
        }),
    },
  };
}

function trimTrailingSlash(value: string): string {
  return value.replace(/\/+$/, "");
}

function toQuery(input: Record<string, unknown>): string {
  const params = new URLSearchParams();
  for (const key of Object.keys(input)) {
    const value = input[key];
    if (value === undefined || value === null || value === "") continue;
    params.set(key, String(value));
  }
  const query = params.toString();
  return query ? `?${query}` : "";
}

async function fetchWithAuth(url: string, input: {
  method: "GET" | "POST";
  apiKey?: string;
  idempotencyKey?: string;
  body?: object;
  fetchApi?: typeof fetch;
}): Promise<unknown> {
  const fetcher = input.fetchApi || fetch;
  const response = await fetcher(url, {
    method: input.method,
    headers: {
      Accept: "application/json",
      ...(input.body ? { "Content-Type": "application/json" } : {}),
      ...(input.apiKey ? { "X-DataBase-Api-Key": input.apiKey } : {}),
      ...(input.idempotencyKey ? { "X-DataBase-Idempotency-Key": input.idempotencyKey } : {}),
    },
    body: input.body ? JSON.stringify(input.body) : undefined,
  });
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) {
    throw new Error(`DataBase Gateway ${input.method} ${url} failed: ${(data as any)?.message || response.statusText}`);
  }
  return data;
}

function makeRequestId(): string {
  return `dbclient_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

function stableHash(value: unknown): string {
  const input = stableStringify(value);
  let hash = 2166136261;
  for (let index = 0; index < input.length; index += 1) {
    hash ^= input.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0).toString(36);
}

function stableStringify(value: unknown): string {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map((item) => stableStringify(item)).join(",")}]`;
  const object = value as Record<string, unknown>;
  return `{${Object.keys(object)
    .sort()
    .map((key) => `${JSON.stringify(key)}:${stableStringify(object[key])}`)
    .join(",")}}`;
}
